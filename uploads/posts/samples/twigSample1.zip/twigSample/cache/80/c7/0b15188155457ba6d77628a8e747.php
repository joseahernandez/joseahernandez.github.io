<?php

/* index.twig.html */
class __TwigTemplate_80c70b15188155457ba6d77628a8e747 extends Twig_Template
{
    protected $parent;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'subtitulo' => array($this, 'block_subtitulo'),
            'contenido' => array($this, 'block_contenido'),
        );
    }

    public function getParent(array $context)
    {
        if (null === $this->parent) {
            $this->parent = $this->env->loadTemplate("layout.twig.html");
        }

        return $this->parent;
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $context = array_merge($this->env->getGlobals(), $context);

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_subtitulo($context, array $blocks = array())
    {
        // line 4
        echo "\tBienvenido a la página de moviles para todos
";
    }

    // line 7
    public function block_contenido($context, array $blocks = array())
    {
        // line 8
        echo "\t<p>
\t\tEn esta página podrás encontrar información acerca de los moviles disponibles en el mercado, así como su precio y diferentes descuentos que puedes encontrar...
\t\tLorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo blandit luctus. Phasellus congue porta semper. Etiam risus lacus, vestibulum a aliquam id, rhoncus sit amet sapien. Sed auctor nibh ut risus dictum sit amet dignissim libero consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur blandit, nibh ac mollis venenatis, risus nunc varius tellus, a pulvinar risus velit quis nisl. Etiam ut est a dui ornare adipiscing. Phasellus quis nisi vel tortor molestie feugiat sit amet sit amet nisi. Maecenas magna arcu, lobortis vel tristique ac, lacinia eget enim. Mauris condimentum sem nec eros sagittis accumsan gravida lorem tempus. Maecenas sit amet metus mauris, ut viverra leo.
\t</p>
\t<p>
\t\tDonec aliquam aliquam fermentum. Fusce volutpat, nisl sed gravida gravida, leo libero bibendum ante, id cursus tortor sapien non turpis. Integer ultricies, felis blandit accumsan dictum, mi odio mattis diam, sit amet porttitor mi massa nec est. Sed bibendum hendrerit tortor non rutrum. Cras egestas dictum ultricies. Suspendisse a lobortis justo. Curabitur ut magna nec eros euismod posuere vitae id metus. Suspendisse venenatis luctus condimentum. Donec euismod auctor luctus. Aliquam sapien libero, laoreet et congue et, lobortis nec erat. Morbi viverra, tortor in pretium consectetur, sem est mattis ligula, non dignissim augue dui vel metus. Curabitur eget blandit tortor. Nam consequat, diam a semper consectetur, lacus nisi dictum turpis, a congue est mauris non orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Maecenas aliquet turpis vitae tellus sollicitudin nec mattis augue ultricies. Ut a ligula dui. Aenean nec nisi dui.
\t</p>
\t<p>
\t\tPellentesque volutpat fermentum tellus in pulvinar. Vivamus eu felis eget leo rhoncus dapibus quis et arcu. Praesent quis consectetur enim. Ut arcu orci, facilisis et auctor in, accumsan pharetra nunc. Duis justo mi, cursus non ultrices vitae, semper eu nisi. Sed tincidunt lobortis leo quis placerat. Quisque sapien neque, aliquam mollis vulputate a, tristique et eros. In hac habitasse platea dictumst. Etiam ultrices lectus et ante rhoncus sit amet sagittis tellus tincidunt. Phasellus commodo volutpat augue, sit amet consectetur est pretium ut. Aenean mollis dignissim risus, eget pharetra augue condimentum et. Ut condimentum dolor ac ligula blandit sed accumsan elit pretium. Vivamus quis condimentum nunc.
\t</p>
\t<p>
\t\tMorbi neque nulla, ullamcorper vitae porttitor vitae, hendrerit eu nibh. Proin elit justo, accumsan sed lacinia vel, venenatis vitae quam. Sed lacus neque, consectetur luctus euismod ut, ultrices at purus. Cras ullamcorper pretium sem, non sodales quam viverra eu. Suspendisse laoreet tincidunt porta. Aenean ultrices fringilla consequat. Nam faucibus metus dignissim libero blandit non porttitor dolor interdum. Cras et purus orci, vel faucibus enim. Praesent nibh libero, malesuada vitae imperdiet et, mollis id sem. Praesent sit amet mauris eu ligula iaculis pretium non in tellus. Ut id nisl nibh, ut fringilla lorem. Mauris nec turpis enim. Etiam rhoncus ante elementum est fringilla imperdiet. Vivamus a justo velit.
\t</p>
\t<p>
\t\tMaecenas laoreet ligula sed mi gravida in tempor nisi consectetur. Vestibulum at vehicula tortor. Vestibulum nunc libero, sollicitudin quis porttitor eget, mollis a dolor. Quisque elementum tempor sapien. Nullam condimentum arcu id neque egestas vitae bibendum lorem dictum. Mauris vulputate imperdiet tristique. Nam in ipsum ut diam vulputate eleifend. Maecenas sed ipsum vel est fringilla luctus at eu lacus. Duis sollicitudin ipsum vitae urna ornare tempus. Suspendisse et nisi nunc. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras at orci sem, vitae semper ligula. Aenean sit amet nibh sed tellus placerat ornare. Sed et lorem ac turpis bibendum imperdiet. Phasellus suscipit convallis libero. Aliquam nec ipsum et dolor facilisis malesuada. Pellentesque rhoncus nibh et leo sagittis iaculis. Duis dignissim molestie tempor. Sed molestie, massa ut ultricies laoreet, mauris sem tincidunt felis, at consequat massa arcu vitae lorem. 
\t</p>
";
    }

    public function getTemplateName()
    {
        return "index.twig.html";
    }

    public function isTraitable()
    {
        return false;
    }
}
