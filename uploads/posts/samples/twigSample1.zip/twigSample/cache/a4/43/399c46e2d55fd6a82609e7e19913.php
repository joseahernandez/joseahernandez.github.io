<?php

/* layout.twig.html */
class __TwigTemplate_a443399c46e2d55fd6a82609e7e19913 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'subtitulo' => array($this, 'block_subtitulo'),
            'contenido' => array($this, 'block_contenido'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $context = array_merge($this->env->getGlobals(), $context);

        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"> 
<html xmlns=\"http://www.w3.org/1999/xhtml\"> 
  <head>
    <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
\t<meta charset=\"utf8\" />
\t<link href=\"css/estilos.css\" rel=\"stylesheet\" />
  </head>
  <body>
    <h1>Moviles para Todos</h1>
    
\t<div class=\"menu\">
\t\t<ul>
\t\t\t<li><a href=\"index.php\">Inicio</a></li>
\t\t\t<li><a href=\"nokia.php\">Nokia</a></li>
\t\t\t<li><a href=\"samsung.php\">Samsung</a></li>
\t\t\t<li><a href=\"htc.php\">HTC</a></li>
\t\t\t<li><a href=\"alcatel.php\">Alcatel</a></li>
\t\t</ul>
\t</div>
\t
\t<h2>";
        // line 21
        $this->displayBlock('subtitulo', $context, $blocks);
        echo "</h2>
\t
    <div>
      ";
        // line 24
        $this->displayBlock('contenido', $context, $blocks);
        // line 26
        echo "    </div>
  <body>
</html>
";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Moviles para Todos";
    }

    // line 21
    public function block_subtitulo($context, array $blocks = array())
    {
    }

    // line 24
    public function block_contenido($context, array $blocks = array())
    {
        // line 25
        echo "      ";
    }

    public function getTemplateName()
    {
        return "layout.twig.html";
    }

    public function isTraitable()
    {
        return false;
    }
}
