package es.jhernandz.getimagefrommysql;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        ListView lvCities = (ListView) findViewById(R.id.lv_cities);
        ArrayList<City> citiesAvaiable = new ArrayList<City>();

        try {
            // Llamamos al servicio web para recuperar los datos
            HttpGet httpGet = new HttpGet("http://192.168.1.129/CitiesService/cities.php");
            HttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = (HttpResponse)httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            BufferedHttpEntity buffer = new BufferedHttpEntity(entity);
            InputStream iStream = buffer.getContent();

            String aux = "";

            BufferedReader r = new BufferedReader(new InputStreamReader(iStream));
            StringBuilder total = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                aux += line;
            }

            // Parseamos la respuesta obtenida del servidor a un objeto JSON
            JSONObject jsonObject = new JSONObject(aux);
            JSONArray cities = jsonObject.getJSONArray("cities");

            // Recorremos el array con los elementos cities
            for(int i = 0; i < cities.length(); i++) {
                JSONObject city = cities.getJSONObject(i);

                // Creamos el objeto City
                City c = new City(city.getInt("id"), city.getString("name"));
                c.setData(city.getString("photo"));

                // Almacenamos el objeto en el array que hemos creado anteriormente
                citiesAvaiable.add(c);
            }
        }
        catch(Exception e) {
            Log.e("WebService", e.getMessage());
        }

        // Creamos el objeto CityAdapter y lo asignamos al ListView
        CityAdapter cityAdapter = new CityAdapter(this, citiesAvaiable);
        lvCities.setAdapter(cityAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
